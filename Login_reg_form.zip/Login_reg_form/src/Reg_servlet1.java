

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Praveen.Register_bean;

/**
 * Servlet implementation class for Servlet: Reg_servlet1
 *
 */
 public class Reg_servlet1 extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
   static final long serialVersionUID = 1L;
   
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public Reg_servlet1() {
		super();
	}   	 	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String firstname=request.getParameter("firstname");
		String lastname=request.getParameter("lastname");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		Register_bean o=new Register_bean();
		o.setFirstname(firstname);
		o.setLastname(lastname);
		o.setUsername(username);
		o.setPassword(password);
		Reg_action ra=new Reg_action();
		boolean status=ra.Registerdetails(o);
		if(status){
			RequestDispatcher r=getServletContext().
				getRequestDispatcher("/RegistrationSuccess.jsp");
			r.forward(request,response);
		}else{
			response.sendRedirect("RegistrationUnsuccess.jsp");
		}
	}   	  	    
}