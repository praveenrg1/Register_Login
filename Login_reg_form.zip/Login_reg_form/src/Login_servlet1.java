

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class for Servlet: Login_servlet1
 *
 */
 public class Login_servlet1 extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
   static final long serialVersionUID = 1L;
   
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public Login_servlet1() {
		super();
	}   	 	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String UserName=request.getParameter("username");
		String Password=request.getParameter("password");
		Login_action la=new Login_action();
		boolean status=la.LoginData(UserName,Password);
		if(status){
			RequestDispatcher rd=getServletContext().
				getRequestDispatcher("/LoginSuccess.jsp");
			rd.forward(request,response);
		}else{
			response.sendRedirect("LoginUnSuccess.jsp");
		}
	}   	  	
	}   	  	    
