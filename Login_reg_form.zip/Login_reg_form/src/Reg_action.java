import java.sql.*;

import Praveen.Register_bean;
public class Reg_action {
	public boolean Registerdetails(Register_bean b){
		boolean status=false;
		String firstname=b.getFirstname();
		String lastname=b.getLastname();
		String username=b.getUsername();
		String password=b.getPassword();
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDeiver");
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		try{
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","praveen","praveen");
			Statement s=con.createStatement();
			ResultSet r=s.executeQuery("select * from register_log where username='"+username+"'and password='"+password+"'");
			if(r.next()){
				status=false;
			}else{
				int i=s.executeUpdate("insert into register_log(firstname,lastname,username,password)" +
						"values('"+firstname+"','"+lastname+"','"+username+"','"+password+"')");
				if(i>0){
					status=true;
				}
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
	return status;
	}
}