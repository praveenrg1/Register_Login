import java.sql.*;

public class Login_action {
	public boolean LoginData(String name,String password){
		boolean status=false;
		
		Connection con=null;
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","praveen","praveen");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from register_log where username='"+name+"' and password='"+password+"'");
			if(rs.next()){
				status=true;
			}
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return status;
	}
}
